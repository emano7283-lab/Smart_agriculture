// طبقة الوصول إلى البيانات - فقط جلب البيانات من ThingSpeak

const THINGSPEAK_CONFIGS = {
    1: { channelID: 3208277, readAPIKey: "RVTF4NUMXYK4RTF2" },
    2: { channelID: 3208297, readAPIKey: "323NA7T2KWBB4WGF" }
};

/**
 * جلب بيانات المستشعرات من ThingSpeak
 * @param {string|number} farmIndex - رقم المزرعة (1 أو 2)
 * @returns {Promise<Object>} بيانات المستشعرات
 */
export async function fetchSensorData(farmIndex) {
    console.log(`📡 جلب بيانات ThingSpeak للمزرعة ${farmIndex}...`);
    
    const config = THINGSPEAK_CONFIGS[farmIndex];
    
    if (!config) {
        throw new Error(`no يوجد تكوين ThingSpeak للمزرعة ${farmIndex}`);
    }
    
    try {
        const response = await fetch(
            `https://api.thingspeak.com/channels/${config.channelID}/feeds.json?api_key=${config.readAPIKey}&results=1`
        );
        
        if (!response.ok) {
            throw new Error( ` error HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.feeds || data.feeds.length === 0) {
            throw new Error('القناة لا تحتوي على بيانات');
        }
        
        const feed = data.feeds[0];
        
        // إرجاع البيانات بنفس الشكل القديم
        return {
            temperature: parseFloat(feed.field1) || 0,
            humidity: parseFloat(feed.field2) || 0,
            light: parseFloat(feed.field3) || 0,
            ph: parseFloat(feed.field4) || 0,
            soilMoisture: parseFloat(feed.field5) || 0,
            rawFeed: feed // البيانات الخام للرجوع إليها
        };
        
    } catch (error) {
        console.error('❌ خطأ في thingspeak-service:', error);
        throw error; // نرمي الخطأ للطبقة الأعلى
    }
}

/**
 * اختبار الاتصال بـ ThingSpeak
 */
export async function testConnection(farmIndex) {
    try {
        const data = await fetchSensorData(farmIndex);
        return {
            connected: true,
            hasData: data.temperature !== 0
        };
    } catch (error) {
        return { connected: false, error: error.message };
    }
}