// business-layer/login.js

function loginUser(email, password) {
  const adminEmail = "admin@gmail.com";
  const adminPass = "12345";

  if (email === adminEmail && password === adminPass) {
    return {
      success: true
    };
  } else {
    return {
      success: false,
      message: "Invalid email or password"
    };
  }
}

module.exports = { loginUser };