// طبقة المنطق - التوصيات والتنبيهات فقط

/**
 * التوصية العامة حسب المحصول (نفس المنطق القديم)
 */
export function getGeneralCropRecommendation(cropType) {
    const recs = {
        tomato: "Ideal temperature 20–28°C. Requires moderate watering.",
        lettuce: "Prefers cool weather and moist soil.",
        corn: "Needs full sunlight and moderate irrigation.",
        wheat: "Grows best in dry climates with moderate watering.",
    };
    
    return recs[cropType] || "No recommendation available.";
}

/**
 * التوصية الذكية حسب القيم (نفس المنطق القديم)
 */
export function getSmartRecommendation(sensorData) {
    const { temperature, humidity, light, ph, soilMoisture } = sensorData;
    
    let smartMsg = "All conditions are optimal.";
    
    if (temperature < 15) smartMsg = "Temperature is too low!";
    else if (temperature > 30) smartMsg = "Temperature is too high!";
    else if (humidity < 30) smartMsg = "Humidity is too low!";
    else if (humidity > 70) smartMsg = "Humidity is too high!";
    else if (light < 100) smartMsg = "Light is too low!";
    else if (light > 500) smartMsg = "Light is too high!";
    else if (ph < 5.5) smartMsg = "pH is too low!";
    else if (ph > 7.5) smartMsg = "pH is too high!";
    else if (soilMoisture < 30) smartMsg = "Turn On The Irrigation";
    else if (soilMoisture > 70) smartMsg = "Turn Off The Irrigation";
    
    return smartMsg;
}

/**
 * توليد التنبيهات (نفس المنطق القديم)
 */
export function generateAlerts(sensorData) {
    const { temperature, humidity, light, ph, soilMoisture } = sensorData;
    const alerts = [];
    
    if (temperature < 15) alerts.push("⚠️ Temperature is too low!");
    if (temperature > 30) alerts.push("⚠️ Temperature is too high!");
    if (humidity < 30) alerts.push("⚠️ Humidity is too low!");
    if (humidity > 70) alerts.push("⚠️ Humidity is too high!");
    if (light < 100) alerts.push("⚠️ Light is too low!");
    if (light > 500) alerts.push("⚠️ Light is too high!");
    if (ph < 5.5) alerts.push("⚠️ pH is too low!");
    if (ph > 7.5) alerts.push("⚠️ pH is too high!");
    if (soilMoisture < 30) alerts.push("🚨 the Soil is very dry!");
    if (soilMoisture > 70) alerts.push("⚠️ the Soil is well moist!");
    
    return alerts;
}

/**
 * تحديد لون الدائرة حسب القيمة
 */
export function getCircleColor(value, min, max) {
    if (value < min) return "red";
    if (value > max) return "yellow";
    return "green";
}

/**
 * تحديد حالة الري
 */
export function getIrrigationStatus(soilMoisture) {
    return soilMoisture < 30 ? "ON" : "OFF";
}