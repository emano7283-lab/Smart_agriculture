// // fields.js - المعدل
// document.addEventListener('DOMContentLoaded', function() {
//     // عناصر الصفحة
//     const btn = document.getElementById("addFieldBtn");
//     const form = document.getElementById("newFieldForm");
//     const overlay = document.getElementById("overlay");
//     const fieldsContainer = document.getElementById("fieldsContainer");

//     // تأكد أن الزر موجود
//     if (!btn) {
//         console.error('❌ زر addFieldBtn غير موجود!');
//         return;
//     }

//     let farmCounter = 1;

//     // فتح الفورم
//     btn.onclick = () => {
//         console.log('✅ تم النقر على زر إضافة مزرعة!');
//         form.style.display = "block";
//         overlay.style.display = "block";
//     };

//     // إغلاق الفورم
//     overlay.onclick = closeForm;
//     function closeForm() {
//         form.style.display = "none";
//         overlay.style.display = "none";
//     }

//     // ✅ إنشاء كرت مزرعة (مع التعديل)
//     function addFieldCard(field) {
//         const card = document.createElement("div");
//         card.className = "fieldCard";

//         card.innerHTML = 
//             `<h3>${field.fieldName}</h3>
//             <p>Area: ${field.area}</p>
//             <p>Soil: ${field.soilType}</p>
//             <p>Crop: ${field.cropType}</p>
//             <button class="dashboard-btn">Go to Dashboard</button>`
//         ;

//         fieldsContainer.appendChild(card);
        
//         // ✅ أضف هذا: زر Dashboard يعمل
//         const dashboardBtn = card.querySelector('.dashboard-btn');
//         dashboardBtn.addEventListener('click', function() {
//             console.log('🚀 انتقل إلى dashboard للمزرعة:', field.fieldName);
//             localStorage.setItem('selectedFarm', JSON.stringify(field));
//             window.location.href = '/dashboard';
//         });
//     }

//     // تحميل المزارع
//     fetch("/get-fields")
//         .then(res => res.json())
//         .then(data => {
//             console.log('📦 عدد المزارع المحملة:', data.fields.length);
//             data.fields.forEach(addFieldCard);
//         })
//         .catch(err => console.error('❌ خطأ في تحميل المزارع:', err));

//     // إرسال الفورم
//     form.onsubmit = function (e) {
//         e.preventDefault();

//         const formData = new FormData(form);
//         const data = Object.fromEntries(formData.entries());

//         fetch("/add-field", {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify(data),
//         })
//             .then(res => res.json())
//             .then(resData => {
//                 if (resData.success) {
//                     addFieldCard(resData.field);
//                     form.reset();
//                     closeForm();
//                 }
//             })
//             .catch(err => console.error('❌ خطأ في إضافة المزرعة:', err));
//     };
    
//     console.log('✅ fields.js محمل وجاهز!');
// });  
// fields.js - المعدل النهائي
document.addEventListener('DOMContentLoaded', function() {
    // عناصر الصفحة
    const btn = document.getElementById("addFieldBtn");
    const form = document.getElementById("newFieldForm");
    const overlay = document.getElementById("overlay");
    const fieldsContainer = document.getElementById("fieldsContainer");

    if (!btn) {
        console.error('❌ زر addFieldBtn غير موجود!');
        return;
    }

    // فتح الفورم
    btn.onclick = () => {
        console.log('✅ تم النقر على زر إضافة مزرعة!');
        form.style.display = "block";
        overlay.style.display = "block";
    };

    // إغلاق الفورم
    overlay.onclick = closeForm;
    function closeForm() {
        form.style.display = "none";
        overlay.style.display = "none";
    }

    // ✅ إنشاء كرت مزرعة (المعدل)
    function addFieldCard(field) {
        const card = document.createElement("div");
        card.className = "fieldCard";

        // ✅ استخدم farmIndex من البيانات المرجعة من السيرفر
        const farmIndex = field.farmIndex || "1";
        
        card.innerHTML = 
            `<h3>${field.fieldName}</h3>
            <p>Area: ${field.area} m²</p>
            <p>Soil: ${field.soilType}</p>
            <p>Crop: ${field.cropType}</p>
            <button class="dashboard-btn" data-farm-index="${farmIndex}">
                Go to Dashboard (Channel ${farmIndex})
            </button>`
        ;

        fieldsContainer.appendChild(card);
        
        // ✅ زر Dashboard - المعدل
        const dashboardBtn = card.querySelector('.dashboard-btn');
        dashboardBtn.addEventListener('click', function() {
            const farmIndex = this.getAttribute('data-farm-index');
            console.log(`🚀 انتقل إلى dashboard للمزرعة: ${field.fieldName}, farmIndex: ${farmIndex}`);
            
            // ✅ إرسال جميع البيانات في URL
            window.location.href = `/dashboard?field=${encodeURIComponent(field.fieldName)}&crop=${encodeURIComponent(field.cropType)}&farmIndex=${farmIndex}`;
        });
    }

    // تحميل المزارع
    fetch("/get-fields")
        .then(res => res.json())
        .then(data => {
            console.log('📦 عدد المزارع المحملة:', data.fields.length);
            
            if (data.fields.length === 0) {
                fieldsContainer.innerHTML = '<p style="text-align:center; color:#666;">لا توجد مزارع بعد. أضف أول مزرعة!</p>';
                return;
            }
            
            // عرض كل المزارع
            data.fields.forEach((field, index) => {
                console.log(` ا ل  م  ز رع ة ${index + 1}:`, field);
                addFieldCard(field);
            });
        })
        .catch(err => {
            console.error('❌ خطأ في تحميل المزارع:', err);
            fieldsContainer.innerHTML = '<p style="color:red; text-align:center;">❌ خطأ في تحميل المزارع</p>';
        });

    // ✅ إرسال الفورم - المعدل
    form.onsubmit = function (e) {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        console.log('📤 إرسال بيانات المزرعة:', data);

        fetch("/add-field", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
        })
            .then(res => {
                if (!res.ok) {
                    throw new Error(`HTTP error! status: ${res.status}`);
                }
                return res.json();
            })
            .then(resData => {
                if (resData.success) {
                    console.log(`✅ مزرعة "${resData.field.fieldName}" أضيفت بنجاح, resData.field`);
                    addFieldCard(resData.field);
                    form.reset();
                    closeForm();
                    // ✅ عرض رسالة نجاح
                    alert(`✅ تم إضافة المزرعة "${resData.field.fieldName}" بنجاح!\nرقم القناة: ${resData.field.farmIndex}`);
                } else {
                    console.error('❌ فشل إضافة المزرعة:', resData.message);
                    alert(`❌ ${resData.message || 'فشل إضافة المزرعة'}`);
                }
            })
            .catch(err => {
                console.error('❌ خطأ في إضافة المزرعة:', err);
                alert('❌ خطأ في إضافة المزرعة. تحقق من اتصال السيرفر.');
            });
    };
    
    console.log('✅ fields.js محمل وجاهز!');
});