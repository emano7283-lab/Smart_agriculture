// // server.js - التعديلات المطلوبة
// const express = require("express");
// const path = require("path");
// const fs = require("fs");
// const bodyParser = require("body-parser");

// // استدعاء الدوال من طبقة الـ Business
// const { loginUser } = require("./project/business-layer/login.js");

// const app = express();
// const PORT = 3000;

// // ========================
// // ✅ التعديل 1: تصحيح المسارات - الأهم!
// // ========================

// // 1. خدمة presentation-layer
// app.use(express.static(path.join(__dirname, "project/presentation-layer")));

// // 2. ✅ إضافة هذا السطر (لخدمة business-layer)
// app.use('/business-layer', express.static(path.join(__dirname, "project/business-layer")));
// app.use('/data-access-layer', express.static(path.join(__dirname, "project/data-access-layer")));
// // 3. ✅ خدمة ملفات CSS والصور
// app.use('/css', express.static(path.join(__dirname, "project/presentation-layer")));
// app.use('/images', express.static(path.join(__dirname, "project/presentation-layer/images")));

// // body parser
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

// // =======================
// // صفحات HTML
// // =======================
// app.get("/", (req, res) => {
//   res.sendFile(path.join(__dirname, "project", "presentation-layer", "home.html"));
// });

// app.get("/sign-in", (req, res) => {
//   res.sendFile(path.join(__dirname, "project", "presentation-layer", "sign-in.html"));
// });

// app.get("/farm", (req, res) => {
//   res.sendFile(path.join(__dirname, "project", "presentation-layer", "farm.html"));
// });

// //
// app.get("/dashboard", (req, res) => {
//   res.sendFile(path.join(__dirname, "project", "presentation-layer", "dashboard.html"));
// });
// // =======================
// // تسجيل الدخول (Business Layer)
// // =======================
// app.post("/login", (req, res) => {
//   const { email, password } = req.body;

//   const result = loginUser(email, password);

//   if (result.success) {
//     console.log("Login Successful!");
//     return res.redirect("/farm");
//   } else {
//     console.log("Invalid email or password");
    
//     fs.readFile(
//       path.join(__dirname, "project", "presentation-layer", "sign-in.html"),
//       "utf8",
//       (err, data) => {
//         if (err) return res.send("Error loading sign-in page");

//         const errorHTML = '<p style="color:red; margin-top:10px;">❌ Email or Password Incorrect!</p>';

//         // ✅ التعديل 2: تصحيح string template
//         data = data.replace("</form>", `${errorHTML}</form>`);
//         res.send(data);
//       }
//     );
//   }
// });

// // =======================
// // حفظ المزارع مؤقتًا (JSON)
// // =======================
// app.post("/add-field", (req, res) => {
//   const { fieldName, area, soilType, LatMin, LatMax, LngMin, LngMax, cropType } = req.body;
//   const newField = {
//     fieldName: String(fieldName || ""),
//     area: Number(area || 0),
//     soilType: String(soilType || ""),
//     latMin: Number(LatMin || 0),
//     latMax: Number(LatMax || 0),
//     lngMin: Number(LngMin || 0),
//     lngMax: Number(LngMax || 0),
//     cropType: String(cropType || ""),
//     createdAt: new Date().toISOString(),
//   };

//   // ✅ التعديل 3: تصحيح __dirname
//   const filePath = path.join(__dirname, "fields.json");

//   fs.readFile(filePath, "utf8", (err, data) => {
//     let fields = [];
//     if (!err) {
//       try {
//         fields = JSON.parse(data);
//         if (!Array.isArray(fields)) fields = [];
//       } catch (e) {
//         fields = [];
//       }
//     }

//     fields.push(newField);

//     fs.writeFile(filePath, JSON.stringify(fields, null, 2), "utf8", (writeErr) => {
//       if (writeErr) {
//         console.error("Error saving field:", writeErr);
//         return res.status(500).json({ success: false });
//       }
//       console.log("Field saved:", newField.fieldName);
//       return res.json({ success: true, field: newField });
//     });
//   });
// });

// // =======================
// // استرجاع جميع المزارع
// // =======================
// app.get("/get-fields", (req, res) => {
//   // ✅ التعديل 4: تصحيح __dirname هنا أيضاً
//   const filePath = path.join(__dirname, "fields.json");
  
//   fs.readFile(filePath, "utf8", (err, data) => {
//     if (err) return res.json({ fields: [] });
//     try {
//       const fields = JSON.parse(data);
//       return res.json({ fields: Array.isArray(fields) ? fields : [] });
//     } catch {
//       return res.json({ fields: [] });
//     }
//   });
// });// =======================
// // بعد routes الأخرى
// app.get("/business-layer/recommendations.js", (req, res) => {
//   const filePath = path.join(__dirname, "project", "business-layer", "recommendations.js");
//   if (fs.existsSync(filePath)) {
//     res.sendFile(filePath);
//   } else {
//     res.status(404).send("File not found");
//   }
// });



// // تشغيل السيرفر
// // =======================
// app.listen(PORT, () => {
//   console.log("🌐 SmartSoil System");
//   console.log(`✅ Server running on http://localhost:${PORT}`);
//   console.log(`✅ Server running on http://localhost:${PORT}/business-layer/recommendations.js`);
// });  

// ========================
const express = require("express");
const path = require("path");
const fs = require("fs");
const bodyParser = require("body-parser");

const { loginUser } = require("./project/business-layer/login.js");

const app = express();
const PORT = 3000;

// ========================
// تكوين المسارات
// ========================
app.use(express.static(path.join(__dirname, "project/presentation-layer")));
app.use('/business-layer', express.static(path.join(__dirname, "project/business-layer")));
app.use('/data-access-layer', express.static(path.join(__dirname, "project/data-access-layer")));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// =======================
// صفحات HTML
// =======================
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "project", "presentation-layer", "home.html"));
});

app.get("/sign-in", (req, res) => {
  res.sendFile(path.join(__dirname, "project", "presentation-layer", "sign-in.html"));
});

app.get("/farm", (req, res) => {
  res.sendFile(path.join(__dirname, "project", "presentation-layer", "farm.html"));
});

app.get("/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "project", "presentation-layer", "dashboard.html"));
});

// =======================
// صفحة اختبار المسارات
// ========================
app.get("/test-paths", (req, res) => {
  const paths = {
    dashboard: path.join(__dirname, "project", "presentation-layer", "dashboard.html"),
    recommendations: path.join(__dirname, "project", "business-layer", "recommendations.js"),
    thingspeak: path.join(__dirname, "project", "data-access-layer", "thingspeak-service.js")
  };
  
  let html = `<h1>📁 test-path SmartSoil</h1>
              <p>✅ Server is work http://localhost:${PORT}</p>
              <hr>`;
  
  for (const [name, filePath] of Object.entries(paths)) {
    const exists = fs.existsSync(filePath);
    html += `<p><strong>${name}:</strong> ${exists ? '✅ موجود' : '❌ غير موجود'}<br>
             <small>المسار: ${filePath}</small></p>`;
  }
  
  html += `<hr>
           <h2>🔗 روابط للاختبار:</h2>
           <ul>
             <li><a href="/dashboard?field=TestFarm&crop=tomato&farmIndex=1" target="_blank">📊 Dashboard</a></li>
             <li><a href="/business-layer/recommendations.js" target="_blank">🧠 recommendations.js</a></li>
             <li><a href="/data-access-layer/thingspeak-service.js" target="_blank">📡 thingspeak-service.js</a></li>
             <li><a href="/farm" target="_blank">🚜 صفحة المزارع</a></li>
             <li><a href="/" target="_blank">🏠 الصفحة الرئيسية</a></li>
           </ul>`;
  
  res.send(html);
});

// =======================
// تسجيل الدخول
// =======================
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const result = loginUser(email, password);

  if (result.success) {
    return res.redirect("/farm");
  } else {
    fs.readFile(
      path.join(__dirname, "project", "presentation-layer", "sign-in.html"),
      "utf8",
      (err, data) => {
        if (err) return res.send("Error loading sign-in page");
        const errorHTML = '<p style="color:red; margin-top:10px;">❌ Email or Password Incorrect!</p>';
        data = data.replace("</form>", `${errorHTML}</form>`);
        res.send(data);
      }
    );
  }
});

// =======================
// إضافة مزرعة جديدة
// =======================
app.post("/add-field", (req, res) => {
  const { fieldName, area, soilType, LatMin, LatMax, LngMin, LngMax, cropType } = req.body;
  
  const filePath = path.join(__dirname, "fields.json");

  fs.readFile(filePath, "utf8", (err, data) => {
    let fields = [];
    if (!err) {
      try {
        fields = JSON.parse(data);
        if (!Array.isArray(fields)) fields = [];
      } catch (e) {
        fields = [];
      }
    }

    const farmIndex = fields.length + 1;
    
    if (farmIndex > 2) {
      return res.status(400).json({ 
        success: false, 
        message: "❌ الحد الأقصى هو مزرعتين (قناتين ThingSpeak فقط)" 
      });
    }const newField = {
      fieldName: String(fieldName || ""),
      area: Number(area || 0),
      soilType: String(soilType || ""),
      latMin: Number(LatMin || 0),
      latMax: Number(LatMax || 0),
      lngMin: Number(LngMin || 0),
      lngMax: Number(LngMax || 0),
      cropType: String(cropType || ""),
      farmIndex: farmIndex,
      createdAt: new Date().toISOString(),
    };

    fields.push(newField);

    fs.writeFile(filePath, JSON.stringify(fields, null, 2), "utf8", (writeErr) => {
      if (writeErr) {
        console.error("Error saving field:", writeErr);
        return res.status(500).json({ success: false });
      }
      console.log(`✅ مزرعة "${fieldName}" أضيفت كـ farmIndex: ${farmIndex}`);
      return res.json({ success: true, field: newField });
    });
  });
});

// =======================
// استرجاع المزارع
// =======================
app.get("/get-fields", (req, res) => {
  const filePath = path.join(__dirname, "fields.json");
  
  fs.readFile(filePath, "utf8", (err, data) => {
    if (err) return res.json({ fields: [] });
    
    try {
      let fields = JSON.parse(data);
      fields = fields.map((field, index) => ({
        ...field,
        farmIndex: field.farmIndex || (index + 1)
      }));
      
      return res.json({ fields });
    } catch {
      return res.json({ fields: [] });
    }
  });
});

// =======================
// تشغيل السيرفر
// =======================
app.listen(PORT, () => {
  console.log("=".repeat(50));
  console.log("🌐 SmartSoil System Running");
  console.log("=".repeat(50));
  console.log(`✅ Server http://localhost:${PORT}`);
  console.log(`📊 Farmer-page http://localhost:${PORT}/farm`);
  console.log(`🧪 Test-Path http://localhost:${PORT}/test-paths`);
  console.log("=".repeat(50));
});